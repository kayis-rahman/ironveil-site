Ironveil press kit
==================

Name: Ironveil
Developer: Apricotz (apricotz.inc)
Genre: offline turn-based Norse survival strategy game (single player against a rival bot)
Platforms: iPhone, iPad and Android - invitation-only alpha testing
Website: https://ironvei-game.online/
Press contact: social@ironvei-game.online
Price: not announced

Short description
Ironveil is an offline turn-based survival strategy game set on a frozen
island: gather, shelter and outlast a rival bot through one long winter,
one turn at a time. Matches save locally on your device.

Contents
- wordmark.png              Official IRONVEIL wordmark, dark letters (light backgrounds)
- wordmark-dark.png         Official IRONVEIL wordmark, light letters (dark backgrounds)
- wordmark-on-sky.png       Official IRONVEIL wordmark, sky-background variant
- lockup.png                Icon and wordmark lockup
- keyart-menu.png           Key art (1920x1080)
- feature-graphic-1024x500.png  Google Play feature graphic (1024x500)
- app-icon-512.png          App icon (512x512)

Current release status and build information:
https://ironvei-game.online/release/
